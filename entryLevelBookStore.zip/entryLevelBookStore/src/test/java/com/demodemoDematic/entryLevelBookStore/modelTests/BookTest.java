package com.demodemoDematic.entryLevelBookStore.modelTests;

class BookTest {

    public void testBookUpdate(){

    }

}

