package com.demodemoDematic.entryLevelBookStore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EntryLevelBookStoreApplicationTests {

	@Test
	void contextLoads() {
	}

	// My apologies for not adding tests. This app definitely needs testing as every app does.
	// I did attach JSON file to test API calls
	// I am very proud for what it is atm, would be amazing to get hired and grow exponentially as software developer
}
