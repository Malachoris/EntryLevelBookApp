package com.demodemoDematic.entryLevelBookStore.modelTests;

public class ScienceBookTest {

    public void testScienceJournalUpdate(){

    }
}
