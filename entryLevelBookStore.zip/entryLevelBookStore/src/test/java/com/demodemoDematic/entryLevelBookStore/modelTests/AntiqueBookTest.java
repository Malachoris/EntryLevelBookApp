package com.demodemoDematic.entryLevelBookStore.modelTests;

public class AntiqueBookTest {

    public void testAntiqueBookUpdate(){

    }
}
